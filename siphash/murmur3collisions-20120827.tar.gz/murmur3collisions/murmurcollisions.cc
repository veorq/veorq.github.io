/*
 * multicollisions for MurmurHash3
 *
 * MurmurHash3 C++ implementation is available at 
 * http://code.google.com/p/smhasher/wiki/MurmurHash3
 *
 * the function Murmur3Multicollisions finds many different inputs
 * hashing to the same 32-bit value (multicollision)
 * 
 * example output:
 * 32-bit seed 7a0e823a
 * 4-multicollision
 * 16-byte inputs
 * MurmurHash3_x86_32( bdd0c04b5c3995827482773b12acab35 ) = 94d7cf1b
 * MurmurHash3_x86_32( 652fa0565c3946be7482773b12acab35 ) = 94d7cf1b
 * MurmurHash3_x86_32( bdd0c04b5c399582cc23983012ac5c71 ) = 94d7cf1b
 * MurmurHash3_x86_32( 652fa0565c3946becc23983012ac5c71 ) = 94d7cf1b
 *
 * the multicollisions found are "universal": they work for any seed/key
 *
 * authors:
 * Jean-Philippe Aumasson, Daniel J. Bernstein
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include "murmurhash3.h"

// notes:
// 1/5 = 3435973837
// const uint32_t c1 = 0xcc9e2d51; inv = 0xdee13bb1
// const uint32_t c2 = 0x1b873593; inv = 0x56ed309b
// 0x00040000 << 13 = 0x80000000
// block schedule of 6c82a158 is 00040000
// leads to a difference 80000000 in h1 after this block
// block schedule of 3bb10000 is 80000000

uint32_t invert32( const uint32_t x ) {
  uint32_t y = x;
  y *=0x56ed309b;
  y = ( y>>15 ) | (y<<17);
  y *=0xdee13bb1;
  return y;
}

void printbytes( const uint8_t *x, int len ) {
  for(int i=0;i<len;++i)
    printf("%02x", x[i]);
}


void Murmur3Multicollisions32( int howmany ) {
  const int BLOCKS=howmany;
  const int COLLISIONS = (1<<howmany); 
  uint8_t in[8*BLOCKS], in0[8*BLOCKS], in1[8*BLOCKS];
  uint8_t out[4];
  int len=8*BLOCKS;
  uint32_t seed=rand();
  // invert order on big-endian machines
  uint8_t diff[] = {0x00,0x00,0x04,0x00,
		    0x00,0x00,0x00,0x80};

  // choose a random input
  for(int i=0;i<8*BLOCKS;++i) {
    in0[i] = rand();
    in1[i] = in0[i] ^ diff[i%8];
  }
  // the magic transform 
  for(int i=0;i<BLOCKS;++i) {
    ((uint32_t*)in0)[2*i] = invert32( ((uint32_t*)in0)[2*i] ); 
    ((uint32_t*)in0)[2*i+1] = invert32( ((uint32_t*)in0)[2*i+1] ); 
    ((uint32_t*)in1)[2*i] = invert32( ((uint32_t*)in1)[2*i] ); 
    ((uint32_t*)in1)[2*i+1] = invert32( ((uint32_t*)in1)[2*i+1] ); 
  }

  printf("32-bit seed %08x\n", seed);
  printf("%d-multicollision\n", COLLISIONS);
  printf("%d-byte inputs\n", 8*BLOCKS);

  for(int i=0;i<COLLISIONS;++i) {
    memset( in, 0, len );
    for(int j=0;j<BLOCKS;++j) {
      if (i & (1<<j)) memcpy( in+(j*8), in1+(j*8), 8 );
      else	      memcpy( in+(j*8), in0+(j*8), 8 );   
    }
    MurmurHash3_x86_32( in, len, seed, out );
    printf("MurmurHash3_x86_32( ");
    printbytes( in, 8*BLOCKS );
    printf(" ) = %08x\n", ((uint32_t*)out)[0]);
  }
}

uint64_t invert641( const uint64_t x ) {
  uint64_t y = x;
  y *= 0xa81e14edd9de2c7fULL;
  y = ( y>>31 ) | (y<<33);
  y *= 0xa98409e882ce4d7dULL;
  return y;
}

uint64_t invert642( const uint64_t x ) {
  uint64_t y = x;
  y *= 0xa98409e882ce4d7dULL;
  y = ( y>>33 ) | (y<<31);
  y *= 0xa81e14edd9de2c7fULL;
  return y;
}

// target 1st k1 difference 0x0000001000000000
// target 1st k2 difference 0x0000000100000000
// target 1st k1 difference 0x8000000000000000
// target 1st k2 difference 0
void Murmur3Multicollisions64( int howmany ) {
  const int BLOCKS=howmany;
  const int COLLISIONS = (1<<howmany); 
  uint8_t in[32*BLOCKS], in0[32*BLOCKS], in1[32*BLOCKS];
  uint8_t out[16];
  int len=32*BLOCKS;
  uint32_t seed=rand();
  // invert order on big-endian machines
  uint8_t diff[] = {0x00,0x00,0x00,0x00,0x10,0x00,0x00,0x00,
		    0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00, 
		    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80, 
		    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  // choose a random input
  for(int i=0;i<32*BLOCKS;++i) {
    in0[i] = rand();
    in1[i] = in0[i] ^ diff[i%32];
  }
  // the magic transform 
  for(int i=0;i<BLOCKS;++i) {
    ((uint64_t*)in0)[4*i] = invert641( ((uint64_t*)in0)[4*i] ); 
    ((uint64_t*)in0)[4*i+1] = invert642( ((uint64_t*)in0)[4*i+1] ); 
    ((uint64_t*)in0)[4*i+2] = invert641( ((uint64_t*)in0)[4*i+2] ); 
    ((uint64_t*)in0)[4*i+3] = invert642( ((uint64_t*)in0)[4*i+3] ); 

    ((uint64_t*)in1)[4*i] = invert641( ((uint64_t*)in1)[4*i] ); 
    ((uint64_t*)in1)[4*i+1] = invert642( ((uint64_t*)in1)[4*i+1] ); 
    ((uint64_t*)in1)[4*i+2] = invert641( ((uint64_t*)in1)[4*i+2] ); 
    ((uint64_t*)in1)[4*i+3] = invert642( ((uint64_t*)in1)[4*i+3] ); 
  }

  printf("32-bit seed %08x\n", seed);
  printf("%d-multicollision\n", COLLISIONS);
  printf("%d-byte inputs\n", 32*BLOCKS);

  for(int i=0;i<COLLISIONS;++i) {
    memset( in, 0, len );
    for(int j=0;j<BLOCKS;++j) {
      if (i & (1<<j)) memcpy( in+(j*32), in1+(j*32), 32 );
      else	      memcpy( in+(j*32), in0+(j*32), 32 );   
    }
    MurmurHash3_x64_128( in, len, seed, out );
    printf("MurmurHash3_x64_128( ");
    printbytes( in, 32*BLOCKS );
    printf(" ) = %08llx%08llx\n", ((uint64_t*)out)[0],((uint64_t*)out)[1]);
  }
}

int main( int ac, char ** av ) {

  srand( getpid() ); 

  if ( ac < 2 ) { printf("usage: %s log2(#collisions)\n", av[0]); return 1; }
    
  Murmur3Multicollisions32( atoi( av[1] ) );
  Murmur3Multicollisions64( atoi( av[1] ) );

  return 0;
}
