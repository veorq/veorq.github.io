/*
 * multicollisions for MurmurHash2
 *
 * MurmurHash2 C++ implementation is available at 
 * http://code.google.com/p/smhasher/wiki/MurmurHash2
 *
 * the function Murmur2Multicollisions finds many different inputs
 * hashing to the same 32-bit value (multicollision)
 * 
 * example output:
 * 32-bit seed 216f262d
 * 4-multicollision
 * 16-byte inputs
 * MurmurHash2( dc4afa06b090ca2c96ee8d866bebe76d ) = 24c5bf11
 * MurmurHash2( 5c298754306f577a96ee8d866bebe76d ) = 24c5bf11
 * MurmurHash2( dc4afa06b090ca2c16cd1ad4ebc974bb ) = 24c5bf11
 * MurmurHash2( 5c298754306f577a16cd1ad4ebc974bb ) = 24c5bf11
 *
 * the multicollisions found are "universal": they work for any seed/key
 *
 * authors:
 * Jean-Philippe Aumasson, Daniel J. Bernstein
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

uint32_t MurmurHash2 ( const void * key, int len, uint32_t seed );

uint32_t invert( const uint32_t x ) {
  uint32_t y = x;
  y *=0xe59b19bd;
  y ^= (y>>24);
  y *=0xe59b19bd;
  return y;
}

void printbytes( const uint8_t *x, int len ) {
  for(int i=0;i<len;++i)
    printf("%02x", x[i]);
}

void Murmur2Multicollisions( int howmany ) {
  const int BLOCKS=howmany;
  const int COLLISIONS = (1<<howmany); 
  uint8_t in[8*BLOCKS], in0[8*BLOCKS], in1[8*BLOCKS];
  uint8_t out[4];
  int len=8*BLOCKS;
  uint32_t h;
  uint32_t seed=rand();
  // invert order on big-endian machines
  uint8_t diff[] = {0x00,0x00,0x00,0x80,
		    0x00,0x00,0x00,0x80};

  // choose a random input
  for(int i=0;i<8*BLOCKS;++i) {
    in0[i] = rand();
    in1[i] = in0[i] ^ diff[i%8];
  }
  // the magic transform 
  for(int i=0;i<BLOCKS;++i) {
    ((uint32_t*)in0)[2*i] = invert( ((uint32_t*)in0)[2*i] ); 
    ((uint32_t*)in0)[2*i+1] = invert( ((uint32_t*)in0)[2*i+1] ); 
    ((uint32_t*)in1)[2*i] = invert( ((uint32_t*)in1)[2*i] ); 
    ((uint32_t*)in1)[2*i+1] = invert( ((uint32_t*)in1)[2*i+1] ); 
  }

  printf("32-bit seed %08x\n", seed);
  printf("%d-multicollision\n", COLLISIONS);
  printf("%d-byte inputs\n", 8*BLOCKS);

  for(int i=0;i<COLLISIONS;++i) {
    memset( in, 0, len );
    for(int j=0;j<BLOCKS;++j) {
      if (i & (1<<j)) memcpy( in+(j*8), in1+(j*8), 8 );
      else	      memcpy( in+(j*8), in0+(j*8), 8 );   
    }
    h = MurmurHash2( in, len, seed );
    printf("MurmurHash2( ");
    printbytes( in, 8*BLOCKS );
    printf(" ) = %08x\n", h);
  }
}


int main( int ac, char ** av ) {

  srand( getpid() );

  if ( ac < 2 ) { printf("usage: %s log2(#collisions)\n", av[0]); return 1; }
    
  Murmur2Multicollisions( atoi( av[1] ) );

}
