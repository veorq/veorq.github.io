/*
 * multicollisions for CityHash64
 *
 * CityHash64 C++ implementation is available at
 * http://code.google.com/p/cityhash/
 * (see e.g. cityhash-1.0.3/src/city.h)
 *
 * the function City64Multicollisions finds many different inputs
 * hashing to the same 64-bit value (multicollision) 
 *
 * example output with seed=0x5eed:
 * 128-bit key 2bbcec480b65eef96b4667de61271b47
 * CityHash64( dd0f5e464925656e0000000000005eed, 16 ) = 802f838560d3fd67
 * CityHash64( 7d7fb36c60a244710000000000005eee, 16 ) = 802f838560d3fd67
 * CityHash64( 0023fed8ae5436360000000000005eef, 16 ) = 802f838560d3fd67
 * CityHash64( 3a47706fbed9abdd0000000000005ef0, 16 ) = 802f838560d3fd67
 * CityHash64( 64bdfa1002c19e3c0000000000005ef1, 16 ) = 802f838560d3fd67
 * CityHash64( bfdb897d019c69b00000000000005ef2, 16 ) = 802f838560d3fd67
 * CityHash64( abbb27077c8c46910000000000005ef3, 16 ) = 802f838560d3fd67
 * CityHash64( d4c0d64907b541730000000000005ef4, 16 ) = 802f838560d3fd67
 *
 * change the seed for a different set of collisions
 *
 * the multicollisions found are "universal": they work for any key 
 * (128-bit, 64-bit, or none); as evidence, this PoC program determines
 * colliding inputs independently of the random keys k1 and k2
 *
 * compile with -DASCII to only shows printable ASCII inputs
 * (search is not optimized for ASCII characters...)
 *
 * authors:
 * Jean-Philippe Aumasson, Daniel J. Bernstein
 */

#include "city.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>


int ispascii16( unsigned char *s ) {
  for(int i=0;i<16;++i) {
  if ( s[i] < 0x20 ) return 0;
  if ( s[i] > 0x7e ) return 0;
  }
  return 1;
}

void City64Multicollisions( int howmany ) {

  const uint64 ikMul = 0xdc56e6f5090b32d9ULL;
  char s[17]; 
  memset( s, 0, 17 );
  uint64 seed = 0x2148534148202020ULL;

  // use weak randomness for the hash keys
  uint64 k1 = rand() ^  ((uint64)rand()<<32);
  uint64 k2 = rand() ^  ((uint64)rand()<<32);
  printf("128-bit key %llx%llx\n", (unsigned long long)k1, (unsigned long long)k2);

  for(int i=0;i<howmany;++i) { 
    uint64 target = seed+i;
    uint64 b = target;
    b *= ikMul;
    b ^= (b >> 47);
    uint64 hi = target; 
    uint64 hii = hi+16;
    hii = ( hii >> 16 ) | ( hii << 48 );
    uint64 a = (b * ikMul) ^ hii;
    a ^= (a >> 47 );
    uint64 lo = (a * ikMul) ^ hii;

    ((uint64*)s)[0] = lo; 
    ((uint64*)s)[1] = hi; 

#ifdef ASCII
    if (ispascii16((unsigned char*)s)) {
    uint64 hash =CityHash64WithSeeds( s, 16, k1, k2 );  
    printf("CityHash64( %s, 16 ) = %llx\n", s, (unsigned long long)hash );
    }
#else
    uint64 hash =CityHash64WithSeeds( s, 16, k1, k2 );  
    printf("CityHash64( %016llx%016llx, 16 ) = %llx\n", 
	(unsigned long long)lo, 
	(unsigned long long)hi, 
	(unsigned long long)hash );
#endif
  }
}

int main( int ac, char ** av ) {

  srand( getpid() ); 

  if ( ac < 2 ) { printf("usage: %s #collisions\n", av[0]); return 1; }

  City64Multicollisions( atoi( av[1] ) );
}
