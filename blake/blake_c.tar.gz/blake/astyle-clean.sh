#!/bin/sh

# apply astyle formatting to .c and .h files

# WARNING
# "sudo apt-get install" may install a previous version that contains an
# infinite loop bug on Linux; you should download the latest version from
# http://sourceforge.net/projects/astyle/files/

# astyle options (see http://astyle.sourceforge.net/astyle.html)
options="-A1 -s2 -f -p -D -xd -o -O -c -k3 -W3"

astyle -R "./*.c" "./*.cpp" "./.h" $options 
