function [output] = BLAKE256(input_message, input_type, salt_in)
%Overall Control File for BLAKE256 Function
%------------------------------------------
%function [output] = BLAKE256(input_message, input_type, salt)
%
%Encompassing M-file for BLAKE 256 Hash function.  All functions are called
%from (nested within) this function.
%
%Function takes in user's message [input_message], with respect to input
%method [input_type](where 1 = Binary input and 2 = Hexadecimal input), as
%well as the user's salt value [salt].
%Output is the Hash of the input
%
%Created by: David Smith
%Last Edited: 19 MAR 11

global MESSAGE_MATRIX       %Holds message decomposed into 8hex blocks
global LENGTH_ARRAY         %Used for counter, relates to message block counter
global SALT                 %User input salt value
global V_MATRIX             %Matrix used in Rounds
global H_VALUES             %Chain Values passed between chain blocks
global P_MATRIX             %Permutation Matrix - Constant
global CONSTANTS            %Predefined Constants

V_MATRIX = zeros(4, 4, 'uint32');
SALT = zeros(1, 4, 'uint32');
H_VALUES = zeros(1, 8, 'uint32');
P_MATRIX = zeros(10, 16, 'uint32');
CONSTANTS = zeros(1, 16, 'uint32');

%Initialise constants and H_VALUES with the predefined IVs
hash_init();

%Format Message with padding, also define Length Matrix
format_input(input_message, input_type);

dimensions_MESSAGE_MATRIX = size(MESSAGE_MATRIX);
loops = dimensions_MESSAGE_MATRIX(1);

%Pad Hexadecimal salt_in to right length (32 hex characters)
b_temp(1:32) = '0';
if (length(salt_in) > 32),
    b_temp = salt_in(1:32);
    salt_in = b_temp;
elseif (length(salt_in) < 32),
    b_temp(1: length(salt_in)) = salt_in;
    salt_in = b_temp;
end %endif

%Deconstruct salt_in string into SALT's 4*uint32 numbers
for c = 1 : 4,
    b_temp = strcat(salt_in((c*8) - 7), salt_in((c*8) - 6), salt_in((c*8) - 5), salt_in((c*8) - 4), salt_in((c*8) - 3), salt_in((c*8) - 2), salt_in((c*8) - 1), salt_in(c*8));
    
    SALT(c) = uint32( hex2dec( b_temp ) );
end %endfor

for msgblock = 1 : loops,
    %Initialise
    block_init(msgblock);
    
    %Do rounds for chain block
    rounds(msgblock);
    
    %Finalise
    finalise();
end %endfor

%Unlock all function so they can be cleared from memory
munlock block_init;
munlock rounds;
munlock g_fcn;
munlock binary_add32;
munlock binary_rotrite32;
munlock finalise;

output = H_VALUES;

clear global
clear functions

end %function