function [] = block_init(msgblk_no)
%Initialises Each Block in the Chain
%-----------------------------------
%function [] = block_init(msgblk_no)
%
%Creates the V-matrix using the previous H-values, Salt, Constants and
%corresponding message block counter.
%'msgblk_no' corresponds to the Block's position in the chain
%
%Created By: Claire Weston & Joseph Jelley
%Last Edited: 19 MAR 11

mlock;
global H_VALUES V_MATRIX SALT CONSTANTS LENGTH_ARRAY
persistent t0 t1

%Assign V0 -> V7 as the h-values
V_MATRIX(1,1) = H_VALUES(1);
V_MATRIX(1,2) = H_VALUES(2);
V_MATRIX(1,3) = H_VALUES(3);
V_MATRIX(1,4) = H_VALUES(4);
V_MATRIX(2,1) = H_VALUES(5);
V_MATRIX(2,2) = H_VALUES(6);
V_MATRIX(2,3) = H_VALUES(7);
V_MATRIX(2,4) = H_VALUES(8);

%Assign V8 -> V11 by bitxor'ing salt and constants
V_MATRIX(3,1) = bitxor(SALT(1) , CONSTANTS(1));
V_MATRIX(3,2) = bitxor(SALT(2) , CONSTANTS(2));
V_MATRIX(3,3) = bitxor(SALT(3) , CONSTANTS(3));
V_MATRIX(3,4) = bitxor(SALT(4) , CONSTANTS(4));

%Assign V12 -> V15 by bitxor'ing counter and constants
t0 = LENGTH_ARRAY(msgblk_no);
t1 = 0;
V_MATRIX(4,1) = bitxor(t0 , CONSTANTS(5));
V_MATRIX(4,2) = bitxor(t0 , CONSTANTS(6));
V_MATRIX(4,3) = bitxor(t1 , CONSTANTS(7));
V_MATRIX(4,4) = bitxor(t1 , CONSTANTS(8));

end %function