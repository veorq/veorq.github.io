function [hex_msg] = convert_binary2hex(bin_msg)
%Converts a Binary Input to Hexadecimal
%--------------------------------------
%function [hex_msg] = convert_binary2hex(bin_msg)
%
%Function to convert directly from Binary to Hexadecimal
%
%Created By: David Smith
%Last Edited: 19 MAR 11

in_len = length(bin_msg)/4;
  
for n = 1:(in_len),
    %Loop for each block of 4

    temp = strcat( bin_msg(4*n -3), bin_msg(4*n -2), bin_msg(4*n -1), bin_msg(4*n) );

    switch temp,
        case '0000',
            hex_msg(n) = '0';
        case '0001',
            hex_msg(n) = '1';                
        case '0010',
            hex_msg(n) = '2';
        case '0011',
            hex_msg(n) = '3';
        case '0100',
            hex_msg(n) = '4';
        case '0101',
            hex_msg(n) = '5';
        case '0110',
            hex_msg(n) = '6';
        case '0111',
            hex_msg(n) = '7';
        case '1000',
            hex_msg(n) = '8';
        case '1001',
            hex_msg(n) = '9';
        case '1010',
            hex_msg(n) = 'A';
        case '1011',
            hex_msg(n) = 'B';
        case '1100',
            hex_msg(n) = 'C';
        case '1101',
            hex_msg(n) = 'D';
        case '1110',
            hex_msg(n) = 'E';
        case '1111',
            hex_msg(n) = 'F';
        otherwise
            fprintf('Invalid Input in Binary to Hexadecimal Conversion: %s\n\n', temp);
    end %endswitch

end %endfor

end %function

