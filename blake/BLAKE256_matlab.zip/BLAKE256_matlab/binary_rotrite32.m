function [output] = binary_rotrite32(input1,shift_length)
%Binary RIGHT ROTATION function for 32-bit numbers
%-------------------------------------------------
%function [output] = binary_rotrite32(input1,shift_length)
%
%Takes a uint32 input and rotates it to the right as many space as declared
%by 'shift_length'.  During rotation the LSB becomes the MSB.
%
%Created by: Thomas Burgess
%Last Edited: 19 MAR 11

mlock;                      %Retain function in memory
persistent store            %Preserve memory space for variable

store(1:31) = '0';          %Temporary Storage String

%Convert input1 to binary equivalent
input1_bin = dec2bin(input1,32);

%Assign bits to temporary variable 
store(1:shift_length) = input1_bin( (33 - shift_length) : 32 );

%Shift bits left in the input array
input1_bin( (shift_length+1) : 32) = input1_bin(1 : (32 - shift_length));

%Put bits from temporary variable back in input array
input1_bin(1 : shift_length) = store(1:shift_length);

%Convert to uint32 number for output
output = uint32(bin2dec(input1_bin));

end %function
