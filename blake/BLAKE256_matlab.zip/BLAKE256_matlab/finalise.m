function [] = finalise()
%Produces New Chain Values to Output to Next Block
%-------------------------------------------------
%function [] = finalise()
%
%Finalises each Block to create new H-values from previous H-values, the
%V-matrix and Salt.
%
%Created By: Claire Weston & Joseph Jelley
%Last Edited: 19 MAR 11

mlock;          %Preserve function in memory

global H_VALUES V_MATRIX SALT

%Start Assigning New H-values
%Compute h_0
temp1 = bitxor(H_VALUES(1), SALT(1));
temp2 = bitxor(V_MATRIX(1,1), V_MATRIX(3,1));
H_VALUES(1) = bitxor(temp1, temp2);

%Compute h_1
temp1 = bitxor(H_VALUES(2), SALT(2));
temp2 = bitxor(V_MATRIX(1,2), V_MATRIX(3,2));
H_VALUES(2) = bitxor(temp1, temp2);

%Compute h_2
temp1 = bitxor(H_VALUES(3), SALT(3));
temp2 = bitxor(V_MATRIX(1,3), V_MATRIX(3,3));
H_VALUES(3) = bitxor(temp1, temp2);

%Compute h_3
temp1 = bitxor(H_VALUES(4), SALT(4));
temp2 = bitxor(V_MATRIX(1,4), V_MATRIX(3,4));
H_VALUES(4) = bitxor(temp1, temp2);

%Compute h_4
temp1 = bitxor(H_VALUES(5), SALT(1));
temp2 = bitxor(V_MATRIX(2,1), V_MATRIX(4,1));
H_VALUES(5) = bitxor(temp1, temp2);

%Compute h_5
temp1 = bitxor(H_VALUES(6), SALT(2));
temp2 = bitxor(V_MATRIX(2,2), V_MATRIX(4,2));
H_VALUES(6) = bitxor(temp1, temp2);

%Compute h_6
temp1 = bitxor(H_VALUES(7), SALT(3));
temp2 = bitxor(V_MATRIX(2,3), V_MATRIX(4,3));
H_VALUES(7) = bitxor(temp1, temp2);

%Compute h_7
temp1 = bitxor(H_VALUES(8), SALT(4));
temp2 = bitxor(V_MATRIX(2,4), V_MATRIX(4,4));
H_VALUES(8) = bitxor(temp1, temp2);

end %endfunction