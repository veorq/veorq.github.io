function [] = hash_init()
%Function to initialise Global Constants
%---------------------------------------
%function [] = hash_init()
%
%This function initialises the H values (with the predefined Initial Values),
%Constants and Permutation Matrix as definied in the specification for the
%BLAKE-256 specifications.
%
%Created By: Claire Weston & Joseph Jelley
%Last Edited: 19 MAR 11

global H_VALUES CONSTANTS P_MATRIX

%Assign Initial Values to global H_VALUES
IV = ['6A09E667'
    'BB67AE85'
    '3C6EF372'
    'A54FF53A'
    '510E527F'
    '9B05688C'
    '1F83D9AB'
    '5BE0CD19'];
H_VALUES = uint32(hex2dec(IV));


%Constants (global CONSTANTS) definition:
consts = [
    '243F6A88' 
    '85A308D3' 
    '13198A2E' 
    '03707344' 
    'A4093822' 
    '299F31D0' 
    '082EFA98' 
    'EC4E6C89' 
    '452821E6' 
    '38D01377' 
    'BE5466CF' 
    '34E90C6C' 
    'C0AC29B7' 
    'C97C50DD' 
    '3F84D5B5'
    'B5470917'];
CONSTANTS = uint32(hex2dec(consts));

%Permutation Matrix (global P_MATRIX)
perm_matrix = [
    0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15;
    14 10 4 8 9 15 13 6 1 12 0 2 11 7 5 3;
    11 8 12 0 5 2 15 13 10 14 3 6 7 1 9 4;
    7 9 3 1 13 12 11 14 2 6 5 10 4 0 15 8;
    9 0 5 7 2 4 10 15 14 1 11 12 6 8 3 13;
    2 12 6 10 0 11 8 3 4 13 7 5 15 14 1 9;
    12 5 1 15 14 13 4 10 0 7 6 3 9 2 8 11;
    13 11 7 14 12 1 3 9 5 0 15 4 8 6 2 10;
    6 15 14 9 11 3 0 8 12 2 13 7 1 4 10 5;
    10 2 8 4 7 6 1 5 15 11 9 14 3 12 13 0];

%Have to incremental all values by 1 due to MATLAB's matrix accessing which
%starts at 1, not 0.
P_MATRIX = perm_matrix + 1;

end %function