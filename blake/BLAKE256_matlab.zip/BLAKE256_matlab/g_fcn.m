function [a,b,c,d] = g_fcn(a, b, c, d, round_no, fcn_no, msgblk_no)
%G-function for Rounds
%---------------------
%function [a,b,c,d] = g_fcn(a, b, c, d, round_no, fcn_no, msgblk_no)
%
%Function to represent the 'G' functions used in the rounds.  Calculations
%based on the 4 V-matrix values [a, b, c and d], the round number
%[round_no], the G-function numbers [fcn_no] and which message block is
%being processed [msgblk_no].
%
%Created By: Thomas Burgess
%Last Edited: 19 MAR 11

mlock;      %Retain function in memory

global P_MATRIX MESSAGE_MATRIX CONSTANTS

persistent g_temp1 g_temp2              %Keep memory space for local variables
persistent permutation1 permutation2
persistent sigma1 sigma2

%Get permutation matrix reference values
round_no = mod(round_no, 10);
round_no = round_no +1;
permutation1 = 2.*fcn_no +1;
permutation2 = 2.*fcn_no +2;

sigma1 = P_MATRIX(round_no, permutation1);
sigma2 = P_MATRIX(round_no, permutation2);

%Start the calculations:
%First a
g_temp1 = binary_add32(a,b);
g_temp2 = bitxor(MESSAGE_MATRIX(msgblk_no, sigma1), CONSTANTS(sigma2));
a = binary_add32(g_temp1, g_temp2);

%First d
g_temp1 = bitxor(d, a);
d = binary_rotrite32(g_temp1, 16);

%First c
c = binary_add32(c, d);

%First b
g_temp1 = bitxor(b, c);
b = binary_rotrite32(g_temp1, 12);

%Second a
g_temp1 = binary_add32(a,b);
g_temp2 = bitxor(MESSAGE_MATRIX(msgblk_no, sigma2), CONSTANTS(sigma1));
a = binary_add32(g_temp1, g_temp2);

%Second d
g_temp1 = bitxor(d, a);
d = binary_rotrite32(g_temp1, 8);

%Second c
c = binary_add32(c, d);

%Second b
g_temp1 = bitxor(b, c);
b = binary_rotrite32(g_temp1, 7);

end %function