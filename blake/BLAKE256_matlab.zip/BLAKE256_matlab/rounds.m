function [] = rounds(msgblk_no)
%Rounds function - Defines a round and repeates 14 times
%-------------------------------------------------------
%function [] = rounds(msgblk_no)
%
%Function to complete the 14 rounds, calling the corresponding G functions.
%
%Created By: Thomas Burgess
%Last Edited: 19 MAR 11

mlock;      %Retain function in Memory

global V_MATRIX

for round = 0:13,
    
    %For G0
    [V_MATRIX(1,1), V_MATRIX(2,1), V_MATRIX(3,1), V_MATRIX(4,1)] = g_fcn(V_MATRIX(1,1),V_MATRIX(2,1),V_MATRIX(3,1),V_MATRIX(4,1), round, 0, msgblk_no);
    
    %For G1
    [V_MATRIX(1,2), V_MATRIX(2,2), V_MATRIX(3,2), V_MATRIX(4,2)] = g_fcn(V_MATRIX(1,2),V_MATRIX(2,2),V_MATRIX(3,2),V_MATRIX(4,2), round, 1, msgblk_no);
    
    %For G2
    [V_MATRIX(1,3), V_MATRIX(2,3), V_MATRIX(3,3), V_MATRIX(4,3)] = g_fcn(V_MATRIX(1,3),V_MATRIX(2,3),V_MATRIX(3,3),V_MATRIX(4,3), round, 2, msgblk_no);
    
    %For G3
    [V_MATRIX(1,4), V_MATRIX(2,4), V_MATRIX(3,4), V_MATRIX(4,4)] = g_fcn(V_MATRIX(1,4),V_MATRIX(2,4),V_MATRIX(3,4),V_MATRIX(4,4), round, 3, msgblk_no);
    
    %For G4
    [V_MATRIX(1,1), V_MATRIX(2,2), V_MATRIX(3,3), V_MATRIX(4,4)] = g_fcn(V_MATRIX(1,1),V_MATRIX(2,2),V_MATRIX(3,3),V_MATRIX(4,4), round, 4, msgblk_no);
    
    %For G5
    [V_MATRIX(1,2), V_MATRIX(2,3), V_MATRIX(3,4), V_MATRIX(4,1)] = g_fcn(V_MATRIX(1,2),V_MATRIX(2,3),V_MATRIX(3,4),V_MATRIX(4,1), round, 5, msgblk_no);
    
    %For G6
    [V_MATRIX(1,3), V_MATRIX(2,4), V_MATRIX(3,1), V_MATRIX(4,2)] = g_fcn(V_MATRIX(1,3),V_MATRIX(2,4),V_MATRIX(3,1),V_MATRIX(4,2), round, 6, msgblk_no);
    
    %For G7
    [V_MATRIX(1,4), V_MATRIX(2,1), V_MATRIX(3,2), V_MATRIX(4,3)] = g_fcn(V_MATRIX(1,4),V_MATRIX(2,1),V_MATRIX(3,2),V_MATRIX(4,3), round, 7, msgblk_no);
    
end %endfor

end %function