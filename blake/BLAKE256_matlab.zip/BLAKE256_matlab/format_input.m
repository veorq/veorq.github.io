function [] = format_input(input_message, input_type)
%Formats User Input before Entry into BLAKE256 Function
%------------------------------------------------------
%function [] = format_input(input_message, input_type)
%
%Function takes the user's input [input_message] with respect to their
%method of entry [input_type] (see below for further explanation] and
%separates into a 16-wide matrix of 32bit integers, each row
%representing a separate message block.
%The message matrix (global MESSAGE_MATRIX) has as many rows as necessary
%to contain the whole of the user's input, as well as padding and input
%length definition.
%
%Expected input_type values:    1 - Binary Input
%                               2 - Hexadecimal Input
%
%Created By: David Smith
%Last Edited: 19 MAR 11

global MESSAGE_MATRIX LENGTH_ARRAY
persistent leading_one padding_done         %Preserve Memory space for variables
leading_one = false;
padding_done = false;

in_len = length(input_message);

if (input_type == 1),
    %If input is binary,
    
    bin_in_len = in_len;
    length_repr = dec2hex(bin_in_len, 16);
    %Binary input translate to message length representation
    
    %Extend binary so it can be converted to hexadecimal
    switch mod(in_len, 4),
        case 0
            leading_one = false;
            %No padding lead '1' added, no change to input_message
            
        case 1
            leading_one = true;
            input_message = strcat(input_message, '100');
            %Added padding lead '1' and extend input_message
            
            in_len = in_len + 3;
            
        case 2
            leading_one = true;
            input_message = strcat(input_message, '10');
            
            in_len = in_len + 2;
            
        case 3
            leading_one = true;
            input_message = strcat(input_message, '1');
            
            in_len = in_len + 1;
            
    end
    
    if (mod(in_len, 512) == 448),
        %In special case of message using 448 bits of final message block
        
        if ((leading_one == true) && (input_message(in_len) == '0'));
            %If padding lead '1' has been added but final bit is '0'
            
            input_message(in_len) = '1';
            %Change to be padding end '1'
            
            padding_done = true;
            %Marking the padding as done
            
        end %endif
        
    end %endif
    
    input_message = convert_binary2hex(input_message);
    
    in_len = length(input_message);
    %Get input length in terms of hex chars
    
else
    
    bin_in_len = in_len*4;
    length_repr = dec2hex( bin_in_len, 16 );
    %Length presentation must count number of bit = 4 * no. of hex chars
    
end %endif

no_of_m_blocks = ceil(in_len/128);

if (padding_done ~= true),
    %If padding hasn't been completed yet
    
    fill_last_m_block = mod(in_len,128);
    
    if ((fill_last_m_block >= 112) || (fill_last_m_block == 0)),
        %Not enough space for padding, add another message block
        
        no_of_m_blocks = no_of_m_blocks +1;
        
    end %endif
        
    %Add Padding + Length Representation to input string
    if (fill_last_m_block == 111),
        %4-bits left for padding before length representation
        
        if (leading_one == true),
            input_message = strcat( input_message, '1' );
        else
            input_message = strcat( input_message, '9' );
        end %endif
        
    else
        %Calculate amount of padding required, add that and length
        %representation to string
    
        rqd_padding = (no_of_m_blocks * 128) - (in_len + 16);
        
        if (leading_one == true),
            
            zerostr(1 : (rqd_padding -1) ) = '0';
            input_message = strcat(input_message, zerostr, '1', length_repr);
            
        else
            
            zerostr(1 : (rqd_padding -2) ) = '0';
            input_message = strcat(input_message, '8', zerostr, '1', length_repr);
            
        end %endif
        
    end %endif
        
else
    
    %Padding has been done, just add Length Representation to input string
    input_message = strcat(input_message, length_repr);
    
end %endif

%Initialise size of MESSAGE_MATRIX
MESSAGE_MATRIX = zeros(no_of_m_blocks, 16, 'uint32');


m_block = 1;
word_block = 1;

for n = 1:(length(input_message)/8),
    %Break input string up into blocks of 8-hex characters and place in
    %MESSAGE_MATRIX
    
    word_hold = strcat( input_message(8*n -7), input_message(8*n -6), input_message(8*n -5), input_message(8*n -4), input_message(8*n -3), input_message(8*n -2), input_message(8*n -1), input_message(8*n) );
                        
    MESSAGE_MATRIX(m_block, word_block) = uint32(hex2dec(word_hold));
    
    word_block = word_block + 1;
    
    if (word_block >= 17),
        %Move to next message block after 16 word blocks
        m_block = m_block +1;
        word_block = 1;
    end %endif          
    
end %endfor


%Produce LENGTH_ARRAY, used by the counter variable during Block
%Initialisation
LENGTH_ARRAY = zeros(no_of_m_blocks, 1);

for n = 1:no_of_m_blocks,
    
    if ( (n * 512) <= bin_in_len ),
        %Still more message to go after this message block
        
        LENGTH_ARRAY(n) = (n * 512);
        
    elseif ( ( (n * 512) > bin_in_len ) && ( ((n - 1) * 512) < bin_in_len ) ),
        %This message block ends the message
        
        LENGTH_ARRAY(n) = bin_in_len;
        
    elseif ( ((n - 1) * 512) >= (bin_in_len) ),
        %This message block has no message in it
        
        LENGTH_ARRAY(n) = 0;
        
    end
    
end

    