function [output] = binary_add32(input1,input2)
%Binary ADD function for 32-bit numbers ignoring Overflow
%--------------------------------------------------------
%function [output] = binary_add32(input1,input2)
%
%Takes two uint32 numbers and adds together.  If the answer is larger than
%2^32 then the answer modulo 2^32 is given as the output.
%
%Created by: Thomas Burgess
%Last Edited: 19 MAR 11

mlock;      %Retain function in memory

output = uint32(input1 + input2);

if (output == ((2^32) - 1)),
    %Block has saturated/Answer larger than 2^32
    %Take modulo of answer
    
    input1 = double(input1);
    input2 = double(input2);
    
    output = mod(input1 + input2, (2^32));
    
    output = uint32(output);
    
end %endif

end %endfunction