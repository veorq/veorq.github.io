BLAKE-256 HASH FUNCTION
-----------------------

The ZIP file 'BLAKE256_matlab.zip' contains two items:

- Folder titled 'BLAKE256_matlab'
- This README file

This README contains instructions on how to install and run the contained MATLAB implementation of the BLAKE hash function.


Installation
------------
Extract the file 'BLAKE-256_final' anywhere onto your system.  

The extracted folder will contain the following files:
- binary_add32.m
- binary_rotrite32.m
- BLAKE256.m
- block_init.m
- convert_binary2hex.m
- finalise.m
- format_input.m
- front_end.m
- g_fcn.m
- hash_init.m
- rounds.m


Running the System
------------------
Open your version of MATLAB and set the 'Current Directory' path to that of the extracted folder.  You will now see the above listed files in the Current Directory window.

In the workspace type "front_end" and press enter.
This will bring up the GUI where the Message and Salt can be entered.

Alternatively, the Hash can be done from the workspace using the 'BLAKE256()' command.  Type 'Help BLAKE256' in the workspace for more information about this method.


Notes on Using the GUI
----------------------
The command 'front_end' brings up a GUI for ease of use.  The following points should be taken into account when using the GUI:

- The radio buttons 'Binary' and 'Hexadecimal' state whether the Message is being input as a binary or hexadecimal respectively.

- The Salt input is always considered to be hexadecimal irrespective of the radio button selected.

- The Salt input is assumed to be 32 characters long,

	- If a Salt input is shorter than this then the input is padded with trailing zeros to make up 32 characters.

	- If a Salt input is longer than this then only the first 32 characters are taken as the Salt.


Accreditation
-------------
The system was made as a collaborative effort by:
- Thomas Burgess (burgess.t@gmail.com)	
- Joseph Jelley		
- David Smith		
- Claire Weston		

Loughborough University, UK
March 2011
